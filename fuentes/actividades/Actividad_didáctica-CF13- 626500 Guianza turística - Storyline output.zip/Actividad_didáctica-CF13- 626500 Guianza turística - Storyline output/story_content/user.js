function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5xF7lfYjn8e":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

